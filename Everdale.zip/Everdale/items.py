from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ItemDef:
    item_id: str
    name: str
    description: str
    category: str
    value: int
    heal: int = 0
    stamina: int = 0
    max_stack: int = 99


ITEM_DEFS: dict[str, ItemDef] = {
    "apple": ItemDef("apple", "Apple", "Crisp orchard fruit. Restores a bit of health.", "food", 8, heal=8),
    "berry": ItemDef("berry", "Wild Berries", "Sweet forest berries. Light healing.", "food", 6, heal=6),
    "mushroom": ItemDef("mushroom", "Cave Mushroom", "Earthy mushroom that restores health and stamina.", "food", 10, heal=7, stamina=12),
    "herb": ItemDef("herb", "Sun Herb", "Medicinal plant used in village remedies.", "resource", 12),
    "wood": ItemDef("wood", "Wood", "Gathered timber used for crafting.", "resource", 4),
    "string": ItemDef("string", "String", "Thin cord used for bows and tools.", "resource", 8),
    "fish": ItemDef("fish", "River Fish", "Fresh fish. Strong healing meal.", "food", 14, heal=14),
    "hearty_stew": ItemDef("hearty_stew", "Hearty Stew", "Warm meal sold by merchants. Strong heal.", "food", 30, heal=24, stamina=10),
    "minor_potion": ItemDef("minor_potion", "Minor Elixir", "Quick healing draught.", "healing", 22, heal=20),
    "stamina_tonic": ItemDef("stamina_tonic", "Stamina Tonic", "Replenishes a chunk of stamina.", "healing", 24, stamina=35),
    "iron_sword": ItemDef("iron_sword", "Iron Sword", "Balanced blade for close combat.", "weapon", 90, max_stack=1),
    "traveler_bow": ItemDef("traveler_bow", "Traveler Bow", "Simple ranged weapon.", "weapon", 100, max_stack=1),
    "ancient_core": ItemDef("ancient_core", "Ancient Core", "Strange relic from old ruins.", "rare", 120),
    "ruins_key": ItemDef("ruins_key", "Ruins Seal Key", "Unlocks the inner ruins gate.", "quest", 0, max_stack=1),
}


def get_item(item_id: str) -> ItemDef:
    return ITEM_DEFS[item_id]
