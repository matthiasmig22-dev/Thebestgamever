from __future__ import annotations

import random
import pygame

import settings
from asset_helpers import TextureBank


T_GRASS = 0
T_PATH = 1
T_WATER = 2
T_TREE = 3
T_ROCK = 4
T_FLOOR = 5
T_RUINS = 6
T_BRIDGE = 7
T_FENCE = 8

# Map / journal POIs: stable ids for discovery + save. Tile coords (not pixels).
WORLD_POIS: list[dict[str, str | int]] = [
    {"id": "eldervale", "name": "Eldervale Village", "tx": 22, "ty": 20, "kind": "settlement"},
    {"id": "gate_east", "name": "East Gate", "tx": 37, "ty": 20, "kind": "gate"},
    {"id": "gate_south", "name": "South Gate", "tx": 22, "ty": 31, "kind": "gate"},
    {"id": "whisperwood", "name": "Whisperwood Forest", "tx": 64, "ty": 24, "kind": "wild"},
    {"id": "sun_orchard", "name": "Sun Orchard", "tx": 30, "ty": 46, "kind": "wild"},
    {"id": "stonehollow", "name": "Stonehollow Cave", "tx": 136, "ty": 26, "kind": "dungeon"},
    {"id": "ashen_ruins", "name": "Ashen Ruins", "tx": 136, "ty": 92, "kind": "ruins"},
    {"id": "ruins_court", "name": "Ruins Inner Court", "tx": 142, "ty": 96, "kind": "ruins"},
    {"id": "road_camp", "name": "Road Camp", "tx": 82, "ty": 96, "kind": "camp"},
    {"id": "hidden_glade", "name": "Hidden Glade", "tx": 165, "ty": 21, "kind": "secret"},
    {"id": "bridge_crossing", "name": "River Bridge", "tx": 124, "ty": 55, "kind": "path"},
    {"id": "old_watchpost", "name": "Old Watchpost", "tx": 94, "ty": 54, "kind": "path"},
    {"id": "riverside", "name": "Riverside Bend", "tx": 54, "ty": 58, "kind": "river"},
    {"id": "river_falls", "name": "River Falls", "tx": 50, "ty": 64, "kind": "river"},
    {"id": "hidden_glade_altar", "name": "Glade Altar", "tx": 68, "ty": 27, "kind": "secret"},
    {"id": "watchtower", "name": "Old Watchtower", "tx": 90, "ty": 45, "kind": "path"},
    {"id": "ruins_lookout", "name": "Ruins Lookout", "tx": 142, "ty": 86, "kind": "ruins"},
    {"id": "npc_rowan", "name": "Elder Rowan", "tx": 22, "ty": 18, "kind": "npc"},
    {"id": "shop_orra", "name": "Orra's Provisions", "tx": 11, "ty": 14, "kind": "merchant"},
    {"id": "shop_lyra", "name": "Lyra's Kitchen", "tx": 26, "ty": 14, "kind": "merchant"},
    {"id": "herbalist_mira", "name": "Mira's Hut", "tx": 14, "ty": 24, "kind": "npc"},
    {"id": "farmer_tobin", "name": "Tobin's Farm", "tx": 30, "ty": 24, "kind": "npc"},
    {"id": "trader_venn", "name": "Venn's Trail Cart", "tx": 86, "ty": 56, "kind": "merchant"},
    {"id": "warden_kael", "name": "Kael's Post", "tx": 82, "ty": 94, "kind": "npc"},
    {"id": "fisher_seli", "name": "Seli's River Spot", "tx": 52, "ty": 58, "kind": "npc"},
    {"id": "cave_bram", "name": "Bram at Stonehollow", "tx": 128, "ty": 26, "kind": "npc"},
    {"id": "relic_iora", "name": "Iora's Relic Stall", "tx": 138, "ty": 86, "kind": "merchant"},
    {"id": "fen_pedlar", "name": "Fen's Secret Trade", "tx": 165, "ty": 20, "kind": "secret"},
]

POI_KIND_COLORS: dict[str, tuple[int, int, int]] = {
    "settlement": (255, 214, 120),
    "gate": (120, 220, 255),
    "wild": (100, 200, 120),
    "dungeon": (180, 120, 255),
    "ruins": (255, 160, 90),
    "camp": (200, 150, 100),
    "secret": (255, 120, 200),
    "path": (160, 150, 140),
    "river": (100, 170, 240),
    "merchant": (255, 230, 80),
    "npc": (150, 200, 255),
}


class World:
    def __init__(self, seed: int = 7) -> None:
        self.rng = random.Random(seed)
        self.w = settings.WORLD_WIDTH_TILES
        self.h = settings.WORLD_HEIGHT_TILES
        self.tiles = [[T_GRASS for _ in range(self.w)] for _ in range(self.h)]
        self.regions: dict[str, pygame.Rect] = {}
        self.landmarks: dict[str, tuple[int, int]] = {}
        self.gatherables: list[dict] = []
        self.weapon_spawns: list[dict] = []
        self.textures = TextureBank(settings.TILE_SIZE)
        self._generate()

    def _fill_rect(self, rect: pygame.Rect, tile: int) -> None:
        for y in range(max(0, rect.top), min(self.h, rect.bottom)):
            for x in range(max(0, rect.left), min(self.w, rect.right)):
                self.tiles[y][x] = tile

    def _noise_scatter(self, rect: pygame.Rect, tile: int, pct: float) -> None:
        for y in range(rect.top, rect.bottom):
            for x in range(rect.left, rect.right):
                if self.rng.random() < pct and 0 <= x < self.w and 0 <= y < self.h:
                    self.tiles[y][x] = tile

    def _generate(self) -> None:
        self.regions = {
            "village": pygame.Rect(8, 8, 30, 24),
            "forest": pygame.Rect(40, 8, 56, 42),
            "orchard": pygame.Rect(18, 38, 26, 22),
            "river": pygame.Rect(0, 50, 180, 18),
            "cave": pygame.Rect(122, 18, 28, 20),
            "ruins": pygame.Rect(118, 78, 42, 34),
            "remote_camp": pygame.Rect(72, 90, 22, 16),
            "hidden_glade": pygame.Rect(158, 14, 14, 14),
        }
        # Base terrain
        for name, rect in self.regions.items():
            if name == "river":
                self._fill_rect(rect, T_WATER)
            elif name in ("cave", "ruins"):
                self._fill_rect(rect, T_FLOOR)
            else:
                self._fill_rect(rect, T_GRASS)

        # Roads / paths
        self._fill_rect(pygame.Rect(20, 20, 120, 3), T_PATH)
        self._fill_rect(pygame.Rect(38, 20, 3, 35), T_PATH)
        self._fill_rect(pygame.Rect(40, 54, 48, 3), T_PATH)
        self._fill_rect(pygame.Rect(86, 54, 3, 40), T_PATH)
        self._fill_rect(pygame.Rect(86, 92, 34, 3), T_PATH)
        self._fill_rect(pygame.Rect(122, 55, 3, 33), T_PATH)
        self._fill_rect(pygame.Rect(122, 54, 8, 3), T_BRIDGE)

        # Village and structures
        for b in (pygame.Rect(12, 12, 8, 6), pygame.Rect(24, 10, 9, 7), pygame.Rect(26, 22, 10, 8), pygame.Rect(10, 23, 10, 7)):
            self._fill_rect(b, T_FLOOR)
        self._fill_rect(pygame.Rect(8, 8, 30, 1), T_FENCE)
        self._fill_rect(pygame.Rect(8, 31, 30, 1), T_FENCE)
        self._fill_rect(pygame.Rect(8, 8, 1, 24), T_FENCE)
        self._fill_rect(pygame.Rect(37, 8, 1, 24), T_FENCE)
        # Main village gates so the player can leave.
        self._fill_rect(pygame.Rect(36, 19, 2, 3), T_PATH)
        self._fill_rect(pygame.Rect(21, 31, 3, 1), T_PATH)

        # Forest / orchard decor
        self._noise_scatter(self.regions["forest"], T_TREE, 0.17)
        self._noise_scatter(self.regions["orchard"], T_TREE, 0.13)
        self._noise_scatter(self.regions["orchard"], T_ROCK, 0.05)
        self._noise_scatter(self.regions["remote_camp"], T_TREE, 0.1)
        self._noise_scatter(self.regions["ruins"], T_RUINS, 0.17)
        self._noise_scatter(self.regions["cave"], T_ROCK, 0.08)

        # Keep paths clear
        for y in range(self.h):
            for x in range(self.w):
                if self.tiles[y][x] in (T_PATH, T_BRIDGE):
                    for oy in (-1, 0, 1):
                        for ox in (-1, 0, 1):
                            tx, ty = x + ox, y + oy
                            if 0 <= tx < self.w and 0 <= ty < self.h and self.tiles[ty][tx] in (T_TREE, T_ROCK):
                                self.tiles[ty][tx] = T_GRASS

        self.landmarks = {
            "Eldervale Village": (22, 20),
            "Whisperwood Forest": (64, 24),
            "Sun Orchard": (30, 46),
            "Stonehollow Cave": (136, 26),
            "Ashen Ruins": (136, 92),
            "Road Camp": (82, 96),
            "Hidden Glade": (165, 21),
            "East Gate": (37, 20),
            "South Gate": (22, 31),
            "Bridge Crossing": (124, 55),
            "Old Watchpost": (94, 54),
            "Riverside Bend": (54, 58),
            "Ruins Court": (142, 96),
        }
        self._spawn_points()

    def _spawn_points(self) -> None:
        self.gatherables = []
        for _ in range(42):
            self.gatherables.append({"tile": self._rand_point(self.regions["orchard"]), "item": "apple", "respawn": 0.0})
        for _ in range(52):
            self.gatherables.append({"tile": self._rand_point(self.regions["forest"]), "item": "berry", "respawn": 0.0})
        for _ in range(28):
            self.gatherables.append({"tile": self._rand_point(self.regions["cave"]), "item": "mushroom", "respawn": 0.0})

        weapon_candidates = [
            ("iron_sword", self.regions["ruins"]),
            ("traveler_bow", self.regions["forest"]),
            ("iron_sword", self.regions["cave"]),
            ("traveler_bow", self.regions["hidden_glade"]),
        ]
        self.weapon_spawns = []
        for wid, rect in weapon_candidates:
            self.weapon_spawns.append({"tile": self._rand_point(rect), "item": wid, "taken": False})

    def _rand_point(self, rect: pygame.Rect) -> tuple[int, int]:
        for _ in range(1000):
            x = self.rng.randint(rect.left, rect.right - 1)
            y = self.rng.randint(rect.top, rect.bottom - 1)
            if self.tiles[y][x] in (T_GRASS, T_FLOOR, T_RUINS):
                return x, y
        return rect.centerx, rect.centery

    def tile_at_px(self, px: float, py: float) -> int:
        tx, ty = int(px // settings.TILE_SIZE), int(py // settings.TILE_SIZE)
        if tx < 0 or ty < 0 or tx >= self.w or ty >= self.h:
            return T_ROCK
        return self.tiles[ty][tx]

    def collides(self, rect: pygame.Rect) -> bool:
        if rect.left < 0 or rect.top < 0:
            return True
        if rect.right >= self.w * settings.TILE_SIZE or rect.bottom >= self.h * settings.TILE_SIZE:
            return True
        ts = settings.TILE_SIZE
        x0, y0 = rect.left // ts, rect.top // ts
        x1, y1 = rect.right // ts, rect.bottom // ts
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                t = self.tiles[y][x]
                if t in (T_WATER, T_TREE, T_ROCK, T_FENCE):
                    return True
        return False

    def region_name_for_px(self, px: float, py: float) -> str:
        tx, ty = int(px // settings.TILE_SIZE), int(py // settings.TILE_SIZE)
        for name, rect in self.regions.items():
            if rect.collidepoint(tx, ty):
                return name
        return "wilds"

    def update(self, dt: float) -> None:
        for g in self.gatherables:
            if g["respawn"] > 0:
                g["respawn"] = max(0.0, g["respawn"] - dt)

    def try_collect_near(self, px: float, py: float) -> str | None:
        ts = settings.TILE_SIZE
        p = pygame.Vector2(px // ts, py // ts)
        for g in self.gatherables:
            if g["respawn"] > 0:
                continue
            gp = pygame.Vector2(g["tile"][0], g["tile"][1])
            if gp.distance_to(p) <= 1.4:
                g["respawn"] = 90.0
                return g["item"]
        for w in self.weapon_spawns:
            if w["taken"]:
                continue
            wp = pygame.Vector2(w["tile"][0], w["tile"][1])
            if wp.distance_to(p) <= 1.1:
                w["taken"] = True
                return w["item"]
        return None

    def draw(self, surf: pygame.Surface, cam_x: float, cam_y: float, day_light: float, anim_time: float = 0.0) -> None:
        ts = settings.TILE_SIZE
        left = max(0, int(cam_x // ts))
        top = max(0, int(cam_y // ts))
        right = min(self.w, left + surf.get_width() // ts + 3)
        bottom = min(self.h, top + surf.get_height() // ts + 3)
        for y in range(top, bottom):
            for x in range(left, right):
                tile_surf = self.textures.tile(self.tiles[y][x], anim_time)
                lit = 0.55 + day_light * 0.55
                shade = max(0, min(255, int(255 * lit)))
                draw_surf = tile_surf.copy()
                draw_surf.fill((shade, shade, shade), special_flags=pygame.BLEND_MULT)
                surf.blit(draw_surf, (x * ts - cam_x, y * ts - cam_y))

        for g in self.gatherables:
            if g["respawn"] > 0:
                continue
            x, y = g["tile"]
            rx, ry = x * ts - cam_x + ts // 2, y * ts - cam_y + ts // 2
            col = (240, 60, 80) if g["item"] == "berry" else (240, 188, 90) if g["item"] == "apple" else (196, 170, 130)
            bob = int((anim_time * 4 + x * 0.2 + y * 0.3) % 2)
            pygame.draw.circle(surf, col, (int(rx), int(ry - bob)), 5)

        for w in self.weapon_spawns:
            if w["taken"]:
                continue
            x, y = w["tile"]
            base = pygame.Rect(int(x * ts - cam_x + ts / 2 - 4), int(y * ts - cam_y + ts / 2 - 14), 8, 18)
            pygame.draw.rect(surf, (195, 206, 228), base)
            pygame.draw.rect(surf, (88, 72, 60), pygame.Rect(base.x - 3, base.bottom - 4, 14, 3))
