from __future__ import annotations

from dataclasses import dataclass, field
import pygame


@dataclass
class NPC:
    npc_id: str
    name: str
    role: str
    x: float
    y: float
    dialogue: list[str]
    quest_hint: str = ""
    shop_id: str | None = None
    path_points: list[tuple[int, int]] | None = field(default=None)
    speed: float = 34.0
    wait_timer: float = 0.0
    target_index: int = 0

    @property
    def rect(self) -> pygame.Rect:
        return pygame.Rect(int(self.x), int(self.y), 24, 24)

    def update(self, dt: float) -> None:
        if not self.path_points:
            return
        if self.wait_timer > 0:
            self.wait_timer = max(0.0, self.wait_timer - dt)
            return
        target_tile = self.path_points[self.target_index]
        target = pygame.Vector2(target_tile[0] * 32 + 4, target_tile[1] * 32 + 4)
        current = pygame.Vector2(self.x, self.y)
        direction = target - current
        distance = direction.length()
        if distance < 2:
            self.target_index = (self.target_index + 1) % len(self.path_points)
            self.wait_timer = 1.0
            return
        movement = direction.normalize() * self.speed * dt
        if movement.length() > distance:
            movement = direction
        self.x += movement.x
        self.y += movement.y

    def draw(self, surf: pygame.Surface, cam_x: float, cam_y: float) -> None:
        r = self.rect.move(-int(cam_x), -int(cam_y))
        color = (212, 215, 130) if self.shop_id else (148, 190, 240)
        pygame.draw.rect(surf, color, r, border_radius=4)


def build_npcs() -> list[NPC]:
    # 15 named NPCs across village + remote regions
    return [
        NPC("rowan", "Elder Rowan", "elder", 22 * 32, 18 * 32, ["Welcome, traveler. Eldervale needs your courage.", "The ruins awaken as night falls."], "Talk to villagers."),
        NPC("mira", "Mira", "herbalist", 14 * 32, 24 * 32, ["Bring me fresh berries and I'll brew a remedy.", "Herbs from the forest carry strong vitality."], "Collect berries."),
        NPC("tobin", "Tobin", "farmer", 30 * 32, 24 * 32, ["The orchard has apples this week.", "Boars have been trampling crops."]),
        NPC("lyra", "Lyra", "food seller", 26 * 32, 14 * 32, ["Warm meals for road-worn heroes.", "Rainy days call for hearty stew."], shop_id="village_food"),
        NPC("orra", "Orra", "general merchant", 11 * 32, 14 * 32, ["Stock up before heading east.", "If you find relics, I pay fair coin."], shop_id="village_goods"),
        NPC("kael", "Kael", "roadwarden", 82 * 32 + 4, 94 * 32 + 4, ["Bandits stalk the road at dusk.", "Keep your blade ready out there."], path_points=[(82, 94), (94, 54), (124, 55), (86, 56)]),
        NPC("venn", "Trader Venn", "traveling merchant", 86 * 32 + 4, 56 * 32 + 4, ["Supplies from cave to coast.", "Bring mushrooms for a better deal."], shop_id="road_trader", path_points=[(86, 56), (94, 54), (124, 55), (82, 96)]),
        NPC("cora", "Cora", "courier", 22 * 32 + 4, 31 * 32 + 4, ["The road is livelier with every passing traveler.", "I carry letters between the village and the camp."], "Deliver the courier's note.", path_points=[(22, 31), (22, 20), (37, 20), (86, 20), (94, 54), (82, 96)]),
        NPC("sylas", "Sylas", "camp guard", 82 * 32 + 8, 96 * 32 + 4, ["This camp keeps the trail safe.", "Rest by the fire before you head east."], "Keep watch over the road."),
        NPC("alyn", "Alyn", "forest guide", 18 * 32, 42 * 32, ["Whisperwood is full of secrets.", "Trees move slower than travelers."], "Learn the safe path through the woods."),
        NPC("seli", "Seli", "fisher", 52 * 32, 58 * 32, ["The river whispers before storms.", "I trade fish for herbs."], "Bring fish to stock the market."),
        NPC("bram", "Bram", "cave explorer", 128 * 32, 26 * 32, ["Stonehollow is deeper than it looks.", "Lurkers hate torchlight."]),
        NPC("iora", "Iora", "relic seeker", 138 * 32, 86 * 32, ["Ancient cores power old mechanisms.", "One key opens the sealed heart."], shop_id="ruins_relics"),
        NPC("fen", "Fen", "hidden peddler", 165 * 32, 20 * 32, ["Not many find this glade.", "Rare goods for curious wanderers."], shop_id="hidden_rare"),
        NPC("thara", "Thara", "bridge keeper", 124 * 32 + 4, 55 * 32 + 4, ["The bridge is safer than it looks when I'm on watch.", "The river swells after rain—mind your footing."], "Ask about the bridge route."),
        NPC("nessa", "Nessa", "herbalist", 57 * 32, 34 * 32, ["I collect moonvine near the falls.", "Herbs love the cool spray of river mist."], "Learn where the best herbs grow."),
        NPC("ida", "Ida", "fisherwoman", 49 * 32, 61 * 32, ["The river gives more than fish if you pay attention.", "A fresh catch makes for a better stew."], "Bring fish for the riverside camp."),
        NPC("joren", "Joren", "ruins scout", 140 * 32, 94 * 32, ["This path into the ruins twists at night.", "I keep watch for strange shadows."], "Ask about ruins dangers."),
    ]
