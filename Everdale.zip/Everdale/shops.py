from __future__ import annotations


SHOPS = {
    "village_food": {
        "name": "Lyra's Kitchen",
        "items": {"apple": 8, "berry": 6, "hearty_stew": 30, "fish": 14},
    },
    "village_goods": {
        "name": "Orra's Provisions",
        "items": {"minor_potion": 22, "stamina_tonic": 24, "herb": 12},
    },
    "road_trader": {
        "name": "Venn's Trail Cart",
        "items": {"mushroom": 10, "hearty_stew": 32, "minor_potion": 24, "iron_sword": 95},
    },
    "ruins_relics": {
        "name": "Iora's Relics",
        "items": {"stamina_tonic": 28, "traveler_bow": 110, "minor_potion": 24},
    },
    "hidden_rare": {
        "name": "Fen's Hidden Goods",
        "items": {"traveler_bow": 130, "iron_sword": 120, "hearty_stew": 35},
    },
}
