from __future__ import annotations

from items import ITEM_DEFS


class Inventory:
    def __init__(self, initial: dict[str, int] | None = None) -> None:
        self._items: dict[str, int] = {}
        if initial:
            for item_id, qty in initial.items():
                if item_id in ITEM_DEFS and qty > 0:
                    self._items[item_id] = int(qty)

    def to_dict(self) -> dict[str, int]:
        return dict(self._items)

    def quantity(self, item_id: str) -> int:
        return self._items.get(item_id, 0)

    def add(self, item_id: str, amount: int = 1) -> bool:
        if amount <= 0 or item_id not in ITEM_DEFS:
            return False
        item = ITEM_DEFS[item_id]
        current = self._items.get(item_id, 0)
        new_amount = min(item.max_stack, current + amount)
        self._items[item_id] = new_amount
        return new_amount > current

    def remove(self, item_id: str, amount: int = 1) -> bool:
        if amount <= 0:
            return False
        current = self._items.get(item_id, 0)
        if current < amount:
            return False
        remain = current - amount
        if remain <= 0:
            self._items.pop(item_id, None)
        else:
            self._items[item_id] = remain
        return True

    def list_items(self) -> list[tuple[str, int]]:
        return sorted(self._items.items(), key=lambda pair: ITEM_DEFS[pair[0]].name)

    def use_consumable(self, item_id: str) -> dict[str, int] | None:
        if self.quantity(item_id) <= 0:
            return None
        item = ITEM_DEFS[item_id]
        if item.category not in ("food", "healing"):
            return None
        if not self.remove(item_id, 1):
            return None
        return {"heal": item.heal, "stamina": item.stamina}
