#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 not found. Attempting to install..."
  if command -v apt-get >/dev/null 2>&1; then
    sudo apt-get update
    sudo apt-get install -y python3 python3-pip
  elif command -v dnf >/dev/null 2>&1; then
    sudo dnf install -y python3 python3-pip
  elif command -v yum >/dev/null 2>&1; then
    sudo yum install -y python3 python3-pip
  elif command -v pacman >/dev/null 2>&1; then
    sudo pacman -Sy --noconfirm python python-pip
  else
    echo "Unsupported package manager. Install Python 3 manually." >&2
    exit 1
  fi
fi

if ! python3 -c "import pygame" >/dev/null 2>&1; then
  echo "Installing Pygame..."
  python3 -m pip install pygame || python3 -m pip install --user pygame
fi

python3 main.py
