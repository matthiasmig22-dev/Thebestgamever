from __future__ import annotations

import random
import pygame


class TextureBank:
    def __init__(self, tile_size: int) -> None:
        self.ts = tile_size
        self.rng = random.Random(42)
        self._tiles: dict[int, pygame.Surface] = {}
        self._build()

    def _noise_tile(self, base: tuple[int, int, int], spread: int = 18) -> pygame.Surface:
        s = pygame.Surface((self.ts, self.ts))
        for y in range(self.ts):
            for x in range(self.ts):
                n = self.rng.randint(-spread, spread)
                c = (max(0, min(255, base[0] + n)), max(0, min(255, base[1] + n)), max(0, min(255, base[2] + n)))
                s.set_at((x, y), c)
        return s

    def _build(self) -> None:
        grass = self._noise_tile((68, 124, 72), 12)
        for _ in range(28):
            pygame.draw.circle(grass, (54, 109, 60), (self.rng.randint(0, self.ts - 1), self.rng.randint(0, self.ts - 1)), 1)
        path = self._noise_tile((142, 118, 88), 10)
        water = self._noise_tile((66, 117, 182), 14)
        rock = self._noise_tile((104, 108, 116), 9)
        floor = self._noise_tile((92, 90, 85), 8)
        ruins = self._noise_tile((116, 108, 100), 10)
        bridge = self._noise_tile((130, 93, 65), 9)
        fence = self._noise_tile((137, 117, 87), 6)
        tree = self._noise_tile((36, 84, 46), 10)
        pygame.draw.circle(tree, (25, 64, 35), (self.ts // 2, self.ts // 2), self.ts // 3)
        self._tiles = {0: grass, 1: path, 2: water, 3: tree, 4: rock, 5: floor, 6: ruins, 7: bridge, 8: fence}

    def tile(self, tile_id: int, anim_time: float) -> pygame.Surface:
        base = self._tiles[tile_id].copy()
        if tile_id == 2:
            # water shimmer
            y = int((anim_time * 35) % self.ts)
            pygame.draw.line(base, (170, 220, 255), (0, y), (self.ts, y), 1)
        return base


def draw_player_sprite(surf: pygame.Surface, rect: pygame.Rect, face: pygame.Vector2, anim_phase: float, hit_flash: bool) -> None:
    body = (255, 132, 132) if hit_flash else (250, 214, 152)
    pygame.draw.ellipse(surf, body, rect)
    leg_shift = int((anim_phase * 3) % 4) - 2
    pygame.draw.rect(surf, (77, 90, 116), pygame.Rect(rect.x + 4, rect.bottom - 6, 6, 4 + leg_shift))
    pygame.draw.rect(surf, (77, 90, 116), pygame.Rect(rect.right - 10, rect.bottom - 6, 6, 4 - leg_shift))
    tip = pygame.Vector2(rect.centerx, rect.centery) + face * 10
    pygame.draw.circle(surf, (44, 58, 84), (int(tip.x), int(tip.y)), 3)


def draw_enemy_sprite(surf: pygame.Surface, rect: pygame.Rect, color: tuple[int, int, int], anim_phase: float, hit_flash: bool) -> None:
    c = (255, 170, 170) if hit_flash else color
    wobble = int((anim_phase * 4) % 3) - 1
    rr = rect.inflate(0, wobble)
    pygame.draw.ellipse(surf, c, rr)
