from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Quest:
    quest_id: str
    title: str
    description: str
    objective: str
    target: int
    reward_money: int
    reward_item: str | None = None
    main: bool = False


QUESTS: dict[str, Quest] = {
    "welcome_to_eldervale": Quest(
        "welcome_to_eldervale",
        "Welcome to Eldervale",
        "Find Elder Rowan in the village and hear what threatens the valley.",
        "talk_rowan",
        1,
        25,
        "apple",
        main=True,
    ),
    "forager_path": Quest(
        "forager_path",
        "Forager's Path",
        "Whisperwood berries are potent—gather 6 for Mira's remedies.",
        "collect_berry",
        6,
        30,
        "minor_potion",
    ),
    "orchard_harvest": Quest(
        "orchard_harvest",
        "Orchard Harvest",
        "The Sun Orchard west of the village is ripe—collect 5 apples.",
        "collect_apple",
        5,
        28,
        "hearty_stew",
    ),
    "cave_cleansing": Quest(
        "cave_cleansing",
        "Cave Cleansing",
        "Stonehollow Cave breeds lurkers. Clear 6 to make the path safe.",
        "kill_lurker",
        6,
        70,
        "stamina_tonic",
        main=True,
    ),
    "roadwarden_help": Quest(
        "roadwarden_help",
        "Roadwarden's Request",
        "Kael reports bandits on the eastern road—cut down 8 of them.",
        "kill_bandit",
        8,
        75,
        "iron_sword",
    ),
    "ruins_signal": Quest(
        "ruins_signal",
        "Signal in the Ruins",
        "Strange lights over the Ashen Ruins—go there and see what stirs.",
        "reach_ruins",
        1,
        50,
        None,
        main=True,
    ),
    "merchant_supply_run": Quest(
        "merchant_supply_run",
        "Supply Run",
        "Gather 4 cave mushrooms from Stonehollow, then speak to Trader Venn on the east trail to deliver them.",
        "talk_venn",
        1,
        55,
        "hearty_stew",
    ),
    "courier_note": Quest(
        "courier_note",
        "Courier's Note",
        "Find Cora and deliver the letter she asks you to carry.",
        "talk_cora",
        1,
        18,
        "herb",
    ),
    "river_rescue": Quest(
        "river_rescue",
        "River Rescue",
        "Seli needs fresh river fish to stock her stall—bring back 3.",
        "collect_fish",
        3,
        32,
        "apple",
    ),
    "forest_herb": Quest(
        "forest_herb",
        "Forest Herb",
        "Collect 3 Sun Herbs for Mira's next strong elixir.",
        "collect_herb",
        3,
        34,
        "minor_potion",
    ),
    "peddler_offer": Quest(
        "peddler_offer",
        "Peddler's Offer",
        "Speak to Fen in the hidden glade and see if he has a rare trinket for travelers.",
        "talk_fen",
        1,
        45,
        "stamina_tonic",
    ),
    "night_watch": Quest(
        "night_watch",
        "Night Watch",
        "The wilds grow cruel after dark—defeat 5 foes between dusk and dawn.",
        "kill_night",
        5,
        80,
        "traveler_bow",
    ),
    "ancient_heart": Quest(
        "ancient_heart",
        "Ancient Heart",
        "Obtain an Ancient Core from the ruins or those who dwell there—Iora knows more.",
        "collect_ancient_core",
        1,
        120,
        "ruins_key",
        main=True,
    ),
    "guardian_of_ashes": Quest(
        "guardian_of_ashes",
        "Guardian of Ashes",
        "At night, a Warden awakens in the Ashen Ruins. Survive its telegraphed strikes and end it.",
        "kill_miniboss",
        1,
        220,
        None,
        main=True,
    ),
}


class QuestLog:
    def __init__(self, active: list[str] | None = None, completed: list[str] | None = None) -> None:
        self.active: dict[str, int] = {}
        self.completed: set[str] = set(completed or [])
        for quest_id in (active or []):
            if quest_id in QUESTS and quest_id not in self.completed:
                self.active[quest_id] = 0

    def ensure(self, quest_id: str) -> None:
        if quest_id in QUESTS and quest_id not in self.completed and quest_id not in self.active:
            self.active[quest_id] = 0

    def progress(self, objective: str, amount: int = 1) -> list[str]:
        completed_now: list[str] = []
        for quest_id in list(self.active):
            quest = QUESTS[quest_id]
            if quest.objective != objective:
                continue
            self.active[quest_id] = min(quest.target, self.active[quest_id] + amount)
            if self.active[quest_id] >= quest.target:
                completed_now.append(quest_id)
        return completed_now

    def complete(self, quest_id: str) -> bool:
        if quest_id not in self.active:
            return False
        self.active.pop(quest_id, None)
        self.completed.add(quest_id)
        return True

    def active_entries(self) -> list[tuple[Quest, int]]:
        return [(QUESTS[qid], prog) for qid, prog in self.active.items() if qid in QUESTS]

    def to_dict(self) -> dict:
        return {"active": dict(self.active), "completed": sorted(self.completed)}
