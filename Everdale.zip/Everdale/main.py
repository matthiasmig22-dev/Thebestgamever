import sys
import traceback

import pygame


WINDOW_WIDTH = 1280
WINDOW_HEIGHT = 720
WINDOW_TITLE = "Everdale - 2D Adventure RPG"
TARGET_FPS = 60


class FallbackGame:
    """
    Temporary fallback so PART 1 is runnable before other modules exist.
    In PART 2+, this gets replaced by the real Game class in game.py.
    """

    def __init__(self, screen: pygame.Surface, clock: pygame.time.Clock) -> None:
        self.screen = screen
        self.clock = clock
        self.font = pygame.font.SysFont("consolas", 28)
        self.small_font = pygame.font.SysFont("consolas", 20)
        self.running = True

    def run(self) -> None:
        while self.running:
            dt = self.clock.tick(TARGET_FPS) / 1000.0
            self._handle_events()
            self._draw(dt)
            pygame.display.flip()

    def _handle_events(self) -> None:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                self.running = False

    def _draw(self, dt: float) -> None:
        self.screen.fill((14, 20, 34))
        title = self.font.render("PART 1 READY: main.py bootstrapped", True, (227, 236, 255))
        subtitle = self.small_font.render(
            "Next parts add world, combat, quests, NPCs, shops, saves, and more.",
            True,
            (159, 178, 214),
        )
        hint = self.small_font.render("Press ESC to quit.", True, (189, 209, 242))
        fps = self.small_font.render(f"FPS: {self.clock.get_fps():.0f}  dt: {dt:.3f}", True, (122, 145, 187))
        self.screen.blit(title, (70, 280))
        self.screen.blit(subtitle, (70, 332))
        self.screen.blit(hint, (70, 380))
        self.screen.blit(fps, (70, 420))


def build_window() -> tuple[pygame.Surface, pygame.time.Clock]:
    pygame.init()
    pygame.mixer.init()
    pygame.display.set_caption(WINDOW_TITLE)
    screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    clock = pygame.time.Clock()
    return screen, clock


def build_game(screen: pygame.Surface, clock: pygame.time.Clock):
    """
    Deferred import keeps startup robust while files are built in parts.
    If game.py is missing or broken, fallback mode still lets us run.
    """
    try:
        from game import Game  # noqa: WPS433 (intentional runtime import)

        return Game(screen=screen, clock=clock)
    except Exception as exc:  # pylint: disable=broad-except
        print("Could not import Game from game.py; running fallback screen instead.")
        print(f"Import error: {exc}")
        traceback.print_exc()
        return FallbackGame(screen=screen, clock=clock)


def main() -> int:
    screen, clock = build_window()
    app = build_game(screen, clock)

    try:
        app.run()
    except Exception as exc:  # pylint: disable=broad-except
        print("\nA fatal error occurred while running the game loop.")
        print(f"Error: {exc}")
        traceback.print_exc()
        return 1
    finally:
        pygame.quit()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
