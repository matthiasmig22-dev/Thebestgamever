from pathlib import Path


# Window
WINDOW_WIDTH = 1280
WINDOW_HEIGHT = 720
WINDOW_SIZE = (WINDOW_WIDTH, WINDOW_HEIGHT)
WINDOW_TITLE = "Legends of the VODKA - 2D Adventure RPG"
TARGET_FPS = 60


# World and camera
TILE_SIZE = 32
WORLD_WIDTH_TILES = 180
WORLD_HEIGHT_TILES = 130
WORLD_PIXEL_WIDTH = WORLD_WIDTH_TILES * TILE_SIZE
WORLD_PIXEL_HEIGHT = WORLD_HEIGHT_TILES * TILE_SIZE


# Save paths
PROJECT_ROOT = Path(__file__).resolve().parent
DATA_DIR = PROJECT_ROOT / "data"
ASSETS_DIR = PROJECT_ROOT / "assets"
SAVE_DIR = DATA_DIR / "saves"
SAVE_FILE = SAVE_DIR / "save_slot_1.json"


# UI colors
COLOR_BG = (16, 20, 28)
COLOR_PANEL = (26, 35, 52)
COLOR_PANEL_ALT = (40, 53, 76)
COLOR_TEXT = (228, 236, 255)
COLOR_TEXT_DIM = (163, 182, 214)
COLOR_ACCENT = (120, 196, 255)
COLOR_WARNING = (235, 131, 131)
COLOR_SUCCESS = (147, 217, 152)


# Default keybinds (rebind system in later parts will use these ids)
DEFAULT_KEYBINDS = {
    "move_up": "w",
    "move_down": "s",
    "move_left": "a",
    "move_right": "d",
    "interact": "e",
    "attack": "j",
    "sprint": "lshift",
    "dodge": "space",
    "inventory": "tab",
    "map": "m",
    "pause": "escape",
    "use_item": "f",
    "quest_log": "k",
}


# Menu labels
MENU_NEW_GAME = "New Game"
MENU_LOAD_GAME = "Load Game"
MENU_RESET_SAVE = "Restart / Reset Save"
MENU_SETTINGS = "Controls / Settings"
MENU_QUIT = "Quit"
