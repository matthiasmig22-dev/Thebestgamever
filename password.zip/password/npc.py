from __future__ import annotations

from dataclasses import dataclass
import pygame


@dataclass
class NPC:
    npc_id: str
    name: str
    role: str
    x: float
    y: float
    dialogue: list[str]
    quest_hint: str = ""
    shop_id: str | None = None

    @property
    def rect(self) -> pygame.Rect:
        return pygame.Rect(int(self.x), int(self.y), 24, 24)

    def draw(self, surf: pygame.Surface, cam_x: float, cam_y: float) -> None:
        r = self.rect.move(-int(cam_x), -int(cam_y))
        color = (212, 215, 130) if self.shop_id else (148, 190, 240)
        pygame.draw.rect(surf, color, r, border_radius=4)


def build_npcs() -> list[NPC]:
    # 11 named NPCs across village + remote regions
    return [
        NPC("rowan", "Elder Rowan", "elder", 22 * 32, 18 * 32, ["Welcome, traveler. Eldervale needs your courage.", "The ruins awaken as night falls."], "Talk to villagers."),
        NPC("mira", "Mira", "herbalist", 14 * 32, 24 * 32, ["Bring me fresh berries and I'll brew a remedy.", "Herbs from the forest carry strong vitality."], "Collect berries."),
        NPC("tobin", "Tobin", "farmer", 30 * 32, 24 * 32, ["The orchard has apples this week.", "Boars have been trampling crops."]),
        NPC("lyra", "Lyra", "food seller", 26 * 32, 14 * 32, ["Warm meals for road-worn heroes.", "Rainy days call for hearty stew."], shop_id="village_food"),
        NPC("orra", "Orra", "general merchant", 11 * 32, 14 * 32, ["Stock up before heading east.", "If you find relics, I pay fair coin."], shop_id="village_goods"),
        NPC("kael", "Kael", "roadwarden", 82 * 32, 94 * 32, ["Bandits stalk the road at dusk.", "Keep your blade ready out there."]),
        NPC("venn", "Trader Venn", "traveling merchant", 86 * 32, 56 * 32, ["Supplies from cave to coast.", "Bring mushrooms for a better deal."], shop_id="road_trader"),
        NPC("seli", "Seli", "fisher", 52 * 32, 58 * 32, ["The river whispers before storms.", "I trade fish for herbs."]),
        NPC("bram", "Bram", "cave explorer", 128 * 32, 26 * 32, ["Stonehollow is deeper than it looks.", "Lurkers hate torchlight."]),
        NPC("iora", "Iora", "relic seeker", 138 * 32, 86 * 32, ["Ancient cores power old mechanisms.", "One key opens the sealed heart."], shop_id="ruins_relics"),
        NPC("fen", "Fen", "hidden peddler", 165 * 32, 20 * 32, ["Not many find this glade.", "Rare goods for curious wanderers."], shop_id="hidden_rare"),
    ]
