from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
import math
import random

import pygame

import settings
from audio_manager import AudioManager
from enemy import Enemy
from inventory import Inventory
from items import ITEM_DEFS
from npc import NPC, build_npcs
from player import Player
from quests import QUESTS, QuestLog
from save_system import SaveSystem
from shops import SHOPS
from spawn_manager import SpawnManager
from world import (
    POI_KIND_COLORS,
    T_BRIDGE,
    T_FENCE,
    T_FLOOR,
    T_GRASS,
    T_PATH,
    T_ROCK,
    T_RUINS,
    T_TREE,
    T_WATER,
    WORLD_POIS,
    World,
)


class GameState(Enum):
    TITLE = auto()
    MAIN_MENU = auto()
    PLAYING = auto()
    PAUSED = auto()
    SETTINGS = auto()
    INVENTORY = auto()
    MAP = auto()
    DIALOGUE = auto()
    SHOP = auto()
    GAME_OVER = auto()


@dataclass
class MenuOption:
    label: str
    action: str


class Game:
    def __init__(self, screen: pygame.Surface, clock: pygame.time.Clock) -> None:
        self.screen = screen
        self.clock = clock
        self.running = True
        self.state = GameState.TITLE
        self.world = World(seed=9)
        self.player = Player(22 * 32, 18 * 32)
        self.npcs: list[NPC] = build_npcs()
        self.enemies: list[Enemy] = []
        self.spawn_manager = SpawnManager(self.world)
        self.audio = AudioManager()
        self.inventory = Inventory()
        self.quest_log = QuestLog(active=["welcome_to_eldervale", "forager_path", "orchard_harvest"], completed=[])
        self.keybinds = dict(settings.DEFAULT_KEYBINDS)
        self.money = 30
        self.time_of_day = 8.0
        self.day_count = 1
        self.weather = "clear"
        self.weather_particles: list[tuple[float, float, float]] = []
        self.map_reveal = [[0 for _ in range(self.world.w)] for _ in range(self.world.h)]
        self.discovered_pois: set[str] = set()
        self.popup = ""
        self.popup_timer = 0.0
        self.dialogue_npc: NPC | None = None
        self.dialogue_index = 0
        self.shop_id: str | None = None
        self.shop_index = 0
        self.inventory_index = 0
        self.settings_index = 0
        self.rebinding: str | None = None
        self.menu_index = 0
        self.cam_x = 0.0
        self.cam_y = 0.0
        self.boss_spawned = False
        self.boss_defeated = False
        self.runtime_seconds = 0.0
        self.autosave_timer = 0.0
        self.font_big = pygame.font.SysFont("segoeui", 62, bold=True)
        self.font_title = pygame.font.SysFont("segoeui", 40, bold=True)
        self.font_ui = pygame.font.SysFont("segoeui", 24)
        self.font_small = pygame.font.SysFont("segoeui", 18)
        self.menu_options = [
            MenuOption(settings.MENU_NEW_GAME, "new_game"),
            MenuOption(settings.MENU_LOAD_GAME, "load_game"),
            MenuOption(settings.MENU_RESET_SAVE, "reset_save"),
            MenuOption(settings.MENU_SETTINGS, "settings"),
            MenuOption(settings.MENU_QUIT, "quit"),
        ]
        self.settings_actions = ["move_up", "move_down", "move_left", "move_right", "interact", "attack", "sprint", "dodge", "inventory", "map", "pause", "use_item"]
        self.load_game(initial=True)

    def run(self) -> None:
        while self.running:
            dt = self.clock.tick(settings.TARGET_FPS) / 1000.0
            self.runtime_seconds += dt
            self.handle_events()
            self.update(dt)
            self.render()
            pygame.display.flip()

    def handle_events(self) -> None:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                self.running = False
            elif self.state == GameState.PLAYING and e.type == pygame.MOUSEBUTTONDOWN:
                if self.keybinds.get("attack", "").lower() == "mouse1" and e.button == 1:
                    self.trigger_attack()
            elif self.state == GameState.TITLE and e.type == pygame.KEYDOWN:
                self.state = GameState.MAIN_MENU
            elif self.state == GameState.MAIN_MENU and e.type == pygame.KEYDOWN:
                self.event_main_menu(e)
            elif self.state == GameState.PLAYING and e.type == pygame.KEYDOWN:
                self.event_playing(e)
            elif self.state == GameState.PAUSED and e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    self.state = GameState.PLAYING
                elif e.key == pygame.K_q:
                    self.manual_save()
                    self.state = GameState.MAIN_MENU
            elif self.state == GameState.INVENTORY and e.type == pygame.KEYDOWN:
                self.event_inventory(e)
            elif self.state == GameState.MAP and e.type == pygame.KEYDOWN:
                if self.is_action_key(e.key, "map") or e.key == pygame.K_ESCAPE:
                    self.state = GameState.PLAYING
            elif self.state == GameState.DIALOGUE and e.type == pygame.KEYDOWN:
                if e.key in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_e):
                    self.advance_dialogue()
                elif e.key == pygame.K_ESCAPE:
                    self.state = GameState.PLAYING
            elif self.state == GameState.SHOP and e.type == pygame.KEYDOWN:
                self.event_shop(e)
            elif self.state == GameState.SETTINGS and e.type == pygame.KEYDOWN:
                self.event_settings(e)
            elif self.state == GameState.GAME_OVER and e.type == pygame.KEYDOWN and e.key == pygame.K_RETURN:
                self.state = GameState.MAIN_MENU

    def update(self, dt: float) -> None:
        self.popup_timer = max(0.0, self.popup_timer - dt)
        if self.state != GameState.PLAYING:
            return
        self.autosave_timer += dt
        if self.autosave_timer > 25:
            self.manual_save()
            self.autosave_timer = 0
            self.set_popup("Autosaved")
        self.world.update(dt)
        self.update_time_weather(dt)
        self.update_player(dt)
        self.update_camera()
        self.update_map_reveal()
        self.update_poi_discovery()
        self.update_enemies(dt)
        self.resolve_quests()
        if self.player.health <= 0:
            self.state = GameState.GAME_OVER

    def update_player(self, dt: float) -> None:
        keys = pygame.key.get_pressed()
        key_state = {a: keys[self.key_to_pg(k)] if self.key_to_pg(k) is not None else False for a, k in self.keybinds.items() if not k.startswith("mouse")}
        mv = self.player.movement_vector(key_state)
        sprinting = key_state.get("sprint", False)
        speed = self.player.get_speed(sprinting)
        self.player.spend_stamina_for_sprint(sprinting, dt)
        self.player.move_with_collision(mv * speed, dt, self.world.collides)
        self.player.update_needs(dt)
        if self.player.attack_timer > 0:
            ar = self.player.attack_rect()
            for enemy in self.enemies:
                if not enemy.dead and enemy.rect.colliderect(ar):
                    died = enemy.take_damage(14 if self.inventory.quantity("iron_sword") <= 0 else 19)
                    if died:
                        self.on_enemy_defeated(enemy)

    def update_enemies(self, dt: float) -> None:
        is_night = self.time_of_day >= 18.0 or self.time_of_day < 6.0
        self.spawn_manager.update(dt, pygame.Vector2(self.player.x, self.player.y), self.enemies, is_night)
        if is_night and not self.boss_spawned and "ancient_heart" in self.quest_log.active:
            rr = self.world.regions["ruins"]
            if rr.collidepoint(int(self.player.x // 32), int(self.player.y // 32)):
                self.enemies.append(Enemy((rr.centerx * 32), (rr.centery * 32), "ruins_warden"))
                self.boss_spawned = True
                self.set_popup("A ruins guardian awakens!")
        for enemy in self.enemies:
            dmg = enemy.update(dt, self.player.rect, self.world.collides, 1.16 if is_night else 1.0)
            if dmg > 0:
                if self.player.take_damage(dmg):
                    self.audio.sfx("player_hit")

    def update_time_weather(self, dt: float) -> None:
        old_day = int(self.time_of_day // 24)
        self.time_of_day = (self.time_of_day + dt * 0.18) % 24.0
        new_day = int(self.time_of_day // 24)
        if new_day != old_day:
            self.day_count += 1
        if 5.9 < self.time_of_day < 6.1 and random.random() < 0.02:
            roll = random.random()
            self.weather = "fog" if roll < 0.2 else "rain" if roll < 0.5 else "clear"
        if self.weather == "rain":
            for _ in range(4):
                self.weather_particles.append((random.uniform(0, settings.WINDOW_WIDTH), random.uniform(0, settings.WINDOW_HEIGHT), random.uniform(230, 320)))
            self.weather_particles = [(x + 2, (y + spd * 0.05) % settings.WINDOW_HEIGHT, spd) for x, y, spd in self.weather_particles[-280:]]

    def update_camera(self) -> None:
        tx = self.player.x - settings.WINDOW_WIDTH / 2 + self.player.w / 2
        ty = self.player.y - settings.WINDOW_HEIGHT / 2 + self.player.h / 2
        max_x = self.world.w * 32 - settings.WINDOW_WIDTH
        max_y = self.world.h * 32 - settings.WINDOW_HEIGHT
        self.cam_x = max(0, min(max_x, tx))
        self.cam_y = max(0, min(max_y, ty))

    def update_map_reveal(self) -> None:
        tx, ty = int(self.player.x // 32), int(self.player.y // 32)
        for y in range(max(0, ty - 6), min(self.world.h, ty + 7)):
            for x in range(max(0, tx - 9), min(self.world.w, tx + 10)):
                self.map_reveal[y][x] = 1

    def _poi_area_explored(self, tx: int, ty: int, radius: int = 3) -> int:
        n = 0
        for dy in range(-radius, radius + 1):
            for dx in range(-radius, radius + 1):
                nx, ny = tx + dx, ty + dy
                if 0 <= nx < self.world.w and 0 <= ny < self.world.h and self.map_reveal[ny][nx]:
                    n += 1
        return n

    def update_poi_discovery(self) -> None:
        px, py = int(self.player.x // 32), int(self.player.y // 32)
        newly: list[dict] = []
        for poi in WORLD_POIS:
            pid = str(poi["id"])
            if pid in self.discovered_pois:
                continue
            tx, ty = int(poi["tx"]), int(poi["ty"])
            dist = math.hypot(px - tx, py - ty)
            explored = self._poi_area_explored(tx, ty, radius=3)
            if dist <= 11 or explored >= 8:
                self.discovered_pois.add(pid)
                newly.append(poi)
        if len(newly) == 1:
            self.set_popup(f"Map: discovered {newly[0]['name']}")
        elif len(newly) > 1:
            self.set_popup(f"Map: discovered {len(newly)} new places")

    def on_enemy_defeated(self, enemy: Enemy) -> None:
        coins, loot = enemy.drop_loot()
        self.money += coins
        if loot:
            self.inventory.add(loot, 1)
            self.quest_log.progress(f"collect_{loot}", 1)
        self.quest_log.progress(f"kill_{enemy.kind}", 1)
        if self.time_of_day >= 18 or self.time_of_day < 6:
            self.quest_log.progress("kill_night", 1)
        if enemy.kind == "ruins_warden":
            self.quest_log.progress("kill_miniboss", 1)
            self.boss_defeated = True
        self.audio.sfx("enemy_defeat")

    def event_main_menu(self, e: pygame.event.Event) -> None:
        if e.key in (pygame.K_DOWN, pygame.K_s):
            self.menu_index = (self.menu_index + 1) % len(self.menu_options)
        elif e.key in (pygame.K_UP, pygame.K_w):
            self.menu_index = (self.menu_index - 1) % len(self.menu_options)
        elif e.key in (pygame.K_RETURN, pygame.K_SPACE):
            action = self.menu_options[self.menu_index].action
            if action == "new_game":
                self.new_game()
                self.state = GameState.PLAYING
            elif action == "load_game":
                self.load_game(initial=False)
                self.state = GameState.PLAYING
            elif action == "reset_save":
                SaveSystem.reset()
                self.new_game()
                self.state = GameState.MAIN_MENU
            elif action == "settings":
                self.state = GameState.SETTINGS
            elif action == "quit":
                self.running = False

    def event_playing(self, e: pygame.event.Event) -> None:
        if self.is_action_key(e.key, "pause"):
            self.state = GameState.PAUSED
        elif self.is_action_key(e.key, "inventory") or e.key == pygame.K_i:
            self.state = GameState.INVENTORY
        elif self.is_action_key(e.key, "map"):
            self.state = GameState.MAP
        elif self.is_action_key(e.key, "dodge"):
            if self.player.try_roll():
                self.audio.sfx("dodge")
        elif self.is_action_key(e.key, "attack"):
            self.trigger_attack()
        elif self.is_action_key(e.key, "interact"):
            self.try_interact()
        elif self.is_action_key(e.key, "use_item"):
            self.use_quick_food()

    def trigger_attack(self) -> None:
        if self.player.try_attack():
            self.audio.sfx("swing")

    def event_inventory(self, e: pygame.event.Event) -> None:
        items = self.inventory.list_items()
        if self.is_action_key(e.key, "inventory") or e.key == pygame.K_ESCAPE:
            self.state = GameState.PLAYING
        elif e.key in (pygame.K_DOWN, pygame.K_s) and items:
            self.inventory_index = (self.inventory_index + 1) % len(items)
        elif e.key in (pygame.K_UP, pygame.K_w) and items:
            self.inventory_index = (self.inventory_index - 1) % len(items)
        elif e.key in (pygame.K_RETURN, pygame.K_f) and items:
            self.use_item(items[self.inventory_index][0])

    def event_shop(self, e: pygame.event.Event) -> None:
        stock = list(SHOPS[self.shop_id]["items"].items()) if self.shop_id else []
        if e.key == pygame.K_ESCAPE:
            self.state = GameState.PLAYING
            return
        if e.key in (pygame.K_DOWN, pygame.K_s) and stock:
            self.shop_index = (self.shop_index + 1) % len(stock)
        elif e.key in (pygame.K_UP, pygame.K_w) and stock:
            self.shop_index = (self.shop_index - 1) % len(stock)
        elif e.key in (pygame.K_RETURN, pygame.K_SPACE) and stock:
            item_id, price = stock[self.shop_index]
            if self.money >= price and self.inventory.add(item_id, 1):
                self.money -= price
                self.set_popup(f"Bought {ITEM_DEFS[item_id].name} for {price}c.")
                self.audio.sfx("shop_buy")
            else:
                self.set_popup("Not enough coins or inventory full.")

    def event_settings(self, e: pygame.event.Event) -> None:
        if self.rebinding:
            if e.key == pygame.K_ESCAPE:
                self.rebinding = None
                return
            new_key = pygame.key.name(e.key)
            if new_key in self.keybinds.values():
                self.set_popup("Key already assigned.")
            else:
                self.keybinds[self.rebinding] = new_key
                self.set_popup(f"Bound {self.rebinding} to {new_key}")
            self.rebinding = None
            return
        if e.key == pygame.K_ESCAPE:
            self.state = GameState.MAIN_MENU
        elif e.key in (pygame.K_DOWN, pygame.K_s):
            self.settings_index = (self.settings_index + 1) % len(self.settings_actions)
        elif e.key in (pygame.K_UP, pygame.K_w):
            self.settings_index = (self.settings_index - 1) % len(self.settings_actions)
        elif e.key in (pygame.K_RETURN, pygame.K_SPACE):
            self.rebinding = self.settings_actions[self.settings_index]

    def try_interact(self) -> None:
        got = self.world.try_collect_near(self.player.x, self.player.y)
        if got:
            self.inventory.add(got, 1)
            self.quest_log.progress(f"collect_{got}", 1)
            self.set_popup(f"Collected {ITEM_DEFS[got].name}.")
            self.audio.sfx("pickup")
            return
        p = self.player.rect
        for npc in self.npcs:
            if npc.rect.colliderect(p.inflate(36, 36)):
                self.dialogue_npc = npc
                self.dialogue_index = 0
                self.state = GameState.DIALOGUE
                self.quest_log.progress(f"talk_{npc.npc_id}", 1)
                if npc.shop_id:
                    self.shop_id = npc.shop_id
                return
        self.set_popup("Nothing to interact with.")

    def get_interact_prompt(self) -> str:
        interact_key = self.keybinds.get("interact", "e").upper()
        ts = settings.TILE_SIZE
        p = pygame.Vector2(self.player.x // ts, self.player.y // ts)
        for g in self.world.gatherables:
            if g["respawn"] > 0:
                continue
            gp = pygame.Vector2(g["tile"][0], g["tile"][1])
            if gp.distance_to(p) <= 1.5:
                item_name = ITEM_DEFS[g["item"]].name
                return f"[{interact_key}] Gather {item_name}"
        for w in self.world.weapon_spawns:
            if w["taken"]:
                continue
            wp = pygame.Vector2(w["tile"][0], w["tile"][1])
            if wp.distance_to(p) <= 1.3:
                item_name = ITEM_DEFS[w["item"]].name
                return f"[{interact_key}] Pick up {item_name}"
        for npc in self.npcs:
            if npc.rect.colliderect(self.player.rect.inflate(36, 36)):
                if npc.shop_id:
                    return f"[{interact_key}] Talk to {npc.name} (shop)"
                return f"[{interact_key}] Talk to {npc.name}"
        return ""

    def advance_dialogue(self) -> None:
        if not self.dialogue_npc:
            self.state = GameState.PLAYING
            return
        self.dialogue_index += 1
        if self.dialogue_index >= len(self.dialogue_npc.dialogue):
            if self.dialogue_npc.shop_id:
                self.shop_id = self.dialogue_npc.shop_id
                self.shop_index = 0
                self.state = GameState.SHOP
            else:
                self.state = GameState.PLAYING
            self.dialogue_index = 0

    def use_quick_food(self) -> None:
        for item in ("hearty_stew", "apple", "berry", "mushroom", "minor_potion", "stamina_tonic"):
            if self.inventory.quantity(item) > 0:
                self.use_item(item)
                return
        self.set_popup("No consumables.")

    def use_item(self, item_id: str) -> None:
        eff = self.inventory.use_consumable(item_id)
        if not eff:
            self.set_popup("Cannot use that item.")
            return
        before_hp = self.player.health
        before_st = self.player.stamina
        self.player.health = min(self.player.max_health, self.player.health + eff["heal"])
        self.player.stamina = min(self.player.max_stamina, self.player.stamina + eff["stamina"])
        healed = int(self.player.health - before_hp)
        stamina = int(self.player.stamina - before_st)
        self.set_popup(f"Used {ITEM_DEFS[item_id].name}: +{healed} HP, +{stamina} ST")
        self.audio.sfx("eat")

    def resolve_quests(self) -> None:
        for qid, prog in list(self.quest_log.active.items()):
            q = QUESTS[qid]
            if prog < q.target:
                continue
            self.quest_log.complete(qid)
            self.money += q.reward_money
            if q.reward_item:
                self.inventory.add(q.reward_item, 1)
            self.set_popup(f"Quest complete: {q.title} (+{q.reward_money}c)")
            self.audio.sfx("quest_done")
            if qid == "welcome_to_eldervale":
                self.quest_log.ensure("ruins_signal")
                self.quest_log.ensure("merchant_supply_run")
            elif qid == "ruins_signal":
                self.quest_log.ensure("cave_cleansing")
                self.quest_log.ensure("roadwarden_help")
            elif qid == "cave_cleansing":
                self.quest_log.ensure("night_watch")
                self.quest_log.ensure("ancient_heart")
            elif qid == "ancient_heart":
                self.quest_log.ensure("guardian_of_ashes")

        region = self.world.region_name_for_px(self.player.x, self.player.y)
        if region == "ruins":
            self.quest_log.progress("reach_ruins", 1)

    def render(self) -> None:
        self.screen.fill((12, 18, 24))
        if self.state == GameState.TITLE:
            self.draw_title()
            return
        if self.state == GameState.MAIN_MENU:
            self.draw_main_menu()
            return
        if self.state in (GameState.PLAYING, GameState.PAUSED, GameState.INVENTORY, GameState.MAP, GameState.DIALOGUE, GameState.SHOP, GameState.GAME_OVER):
            self.draw_world_scene()
            self.draw_hud()
        if self.state == GameState.PAUSED:
            self.draw_pause()
        elif self.state == GameState.INVENTORY:
            self.draw_inventory()
        elif self.state == GameState.MAP:
            self.draw_map()
        elif self.state == GameState.DIALOGUE:
            self.draw_dialogue()
        elif self.state == GameState.SHOP:
            self.draw_shop()
        elif self.state == GameState.SETTINGS:
            self.draw_settings()
        elif self.state == GameState.GAME_OVER:
            self.draw_game_over()

    def draw_title(self) -> None:
        self.screen.fill((18, 28, 44))
        self.screen.blit(self.font_big.render("LEGENDS OF THE WILDS", True, (235, 242, 255)), (148, 220))
        self.screen.blit(self.font_ui.render("Press any key to continue", True, (160, 195, 248)), (480, 420))

    def draw_main_menu(self) -> None:
        self.screen.fill((18, 24, 34))
        self.screen.blit(self.font_title.render("Main Menu", True, settings.COLOR_TEXT), (520, 130))
        panel = pygame.Rect(420, 220, 440, 320)
        pygame.draw.rect(self.screen, settings.COLOR_PANEL, panel, border_radius=10)
        pygame.draw.rect(self.screen, settings.COLOR_PANEL_ALT, panel, 2, border_radius=10)
        for i, o in enumerate(self.menu_options):
            c = settings.COLOR_ACCENT if i == self.menu_index else settings.COLOR_TEXT
            self.screen.blit(self.font_ui.render(("> " if i == self.menu_index else "  ") + o.label, True, c), (470, 262 + i * 52))

    def draw_world_scene(self) -> None:
        daylight = 0.35 + 0.65 * max(0.0, math.sin((self.time_of_day - 6.0) / 24.0 * math.tau))
        self.world.draw(self.screen, self.cam_x, self.cam_y, daylight, self.runtime_seconds)
        for npc in self.npcs:
            npc.draw(self.screen, self.cam_x, self.cam_y)
        for e in self.enemies:
            if not e.dead:
                e.draw(self.screen, self.cam_x, self.cam_y)
        self.player.draw(self.screen, self.cam_x, self.cam_y)
        self.draw_weather_and_light(daylight)

    def draw_weather_and_light(self, daylight: float) -> None:
        alpha = int((1.0 - daylight) * 140)
        if alpha > 0:
            ov = pygame.Surface(settings.WINDOW_SIZE, pygame.SRCALPHA)
            ov.fill((18, 28, 50, alpha))
            self.screen.blit(ov, (0, 0))
        if self.weather == "fog":
            ov = pygame.Surface(settings.WINDOW_SIZE, pygame.SRCALPHA)
            ov.fill((180, 190, 210, 58))
            self.screen.blit(ov, (0, 0))
        elif self.weather == "rain":
            for x, y, _ in self.weather_particles:
                pygame.draw.line(self.screen, (170, 190, 220), (int(x), int(y)), (int(x - 4), int(y + 11)), 1)

    def draw_hud(self) -> None:
        pygame.draw.rect(self.screen, (10, 14, 20), pygame.Rect(8, 8, 680, 146), border_radius=8)
        self.bar(22, 20, 180, self.player.health / self.player.max_health, (220, 74, 74), "HP")
        self.bar(22, 48, 180, self.player.stamina / self.player.max_stamina, (86, 194, 122), "ST")
        self.screen.blit(self.font_small.render(f"Coins: {self.money}", True, settings.COLOR_TEXT), (225, 24))
        self.screen.blit(self.font_small.render(f"Time: {self.time_of_day:04.1f}  Weather: {self.weather}", True, settings.COLOR_TEXT_DIM), (225, 48))
        qtxt = "No active quest"
        entries = self.quest_log.active_entries()
        if entries:
            q, p = entries[0]
            qtxt = f"{q.title} ({p}/{q.target})"
        self.screen.blit(self.font_small.render(qtxt, True, settings.COLOR_TEXT), (225, 76))
        inv_key = self.keybinds.get("inventory", "tab").upper()
        interact_key = self.keybinds.get("interact", "e").upper()
        use_key = self.keybinds.get("use_item", "f").upper()
        self.screen.blit(
            self.font_small.render(
                f"Inventory [{inv_key}]  Interact [{interact_key}]  Eat/Use [{use_key}]",
                True,
                settings.COLOR_TEXT_DIM,
            ),
            (22, 106),
        )
        prompt = self.get_interact_prompt()
        if prompt:
            self.screen.blit(self.font_small.render(prompt, True, settings.COLOR_ACCENT), (22, 126))
        if self.popup_timer > 0:
            self.screen.blit(self.font_small.render(self.popup, True, settings.COLOR_SUCCESS), (380, 126))

    def draw_pause(self) -> None:
        ov = pygame.Surface(settings.WINDOW_SIZE, pygame.SRCALPHA)
        ov.fill((0, 0, 0, 130))
        self.screen.blit(ov, (0, 0))
        self.screen.blit(self.font_title.render("Paused", True, settings.COLOR_TEXT), (560, 280))
        self.screen.blit(self.font_ui.render("ESC Resume | Q Save+Menu", True, settings.COLOR_TEXT_DIM), (430, 340))

    def draw_inventory(self) -> None:
        ov = pygame.Surface(settings.WINDOW_SIZE, pygame.SRCALPHA)
        ov.fill((0, 0, 0, 160))
        self.screen.blit(ov, (0, 0))
        panel = pygame.Rect(200, 84, 880, 550)
        pygame.draw.rect(self.screen, settings.COLOR_PANEL, panel, border_radius=10)
        pygame.draw.rect(self.screen, settings.COLOR_PANEL_ALT, panel, 2, border_radius=10)
        self.screen.blit(self.font_title.render("Inventory", True, settings.COLOR_TEXT), (535, 98))
        entries = self.inventory.list_items()
        for i, (item_id, qty) in enumerate(entries[:14]):
            item = ITEM_DEFS[item_id]
            col = settings.COLOR_ACCENT if i == self.inventory_index else settings.COLOR_TEXT
            self.screen.blit(self.font_ui.render(f"{'> ' if i==self.inventory_index else '  '}{item.name} x{qty} [{item.category}]", True, col), (260, 160 + i * 30))
            if i == self.inventory_index:
                self.screen.blit(self.font_small.render(item.description, True, settings.COLOR_TEXT_DIM), (260, 590))

    def draw_map(self) -> None:
        ov = pygame.Surface(settings.WINDOW_SIZE, pygame.SRCALPHA)
        ov.fill((0, 0, 0, 140))
        self.screen.blit(ov, (0, 0))
        panel = pygame.Rect(40, 36, 1200, 652)
        pygame.draw.rect(self.screen, (14, 18, 28), panel, border_radius=12)
        pygame.draw.rect(self.screen, (72, 98, 138), panel, 2, border_radius=12)

        mw, mh = self.world.w, self.world.h
        legend_w = 280
        map_area_w = panel.width - legend_w - 48
        map_area_h = panel.height - 56
        scale = max(3, min(map_area_w // mw, map_area_h // mh, 6))
        map_pixel_w = mw * scale
        map_pixel_h = mh * scale
        ox = panel.x + 24 + (map_area_w - map_pixel_w) // 2
        oy = panel.y + 48 + (map_area_h - map_pixel_h) // 2

        tile_colors = {
            T_GRASS: (58, 112, 62),
            T_PATH: (132, 108, 78),
            T_WATER: (52, 98, 168),
            T_TREE: (28, 72, 38),
            T_ROCK: (88, 90, 98),
            T_FLOOR: (78, 76, 72),
            T_RUINS: (104, 94, 88),
            T_BRIDGE: (118, 84, 58),
            T_FENCE: (124, 104, 76),
        }
        fog_color = (10, 11, 16)
        for y in range(mh):
            for x in range(mw):
                rx = ox + x * scale
                ry = oy + y * scale
                rect = pygame.Rect(rx, ry, scale, scale)
                if self.map_reveal[y][x] == 0:
                    self.screen.fill(fog_color, rect)
                else:
                    t = self.world.tiles[y][x]
                    self.screen.fill(tile_colors.get(t, (70, 70, 75)), rect)
                    if scale >= 4:
                        pygame.draw.rect(self.screen, (24, 28, 32), rect, 1)

        px, py = int(self.player.x // 32), int(self.player.y // 32)
        pcx = ox + px * scale + scale // 2
        pcy = oy + py * scale + scale // 2
        pygame.draw.circle(self.screen, (40, 40, 50), (pcx + 1, pcy + 2), max(4, scale // 2))
        pygame.draw.circle(self.screen, (255, 230, 140), (pcx, pcy), max(4, scale // 2))
        pygame.draw.circle(self.screen, (255, 255, 255), (pcx, pcy), max(2, scale // 4))

        for poi in WORLD_POIS:
            pid = str(poi["id"])
            if pid not in self.discovered_pois:
                continue
            tx, ty = int(poi["tx"]), int(poi["ty"])
            kind = str(poi.get("kind", "wild"))
            col = POI_KIND_COLORS.get(kind, (200, 200, 200))
            explored_here = self.map_reveal[ty][tx] == 1
            mcx = ox + tx * scale + scale // 2
            mcy = oy + ty * scale + scale // 2
            r = max(3, scale // 2 + 1)
            if not explored_here:
                col = tuple(max(40, c // 3) for c in col)
            pts = [(mcx, mcy - r), (mcx + r, mcy), (mcx, mcy + r), (mcx - r, mcy)]
            pygame.draw.polygon(self.screen, col, pts)
            pygame.draw.polygon(self.screen, (20, 22, 30), pts, width=1)

        map_key = self.keybinds.get("map", "m").upper()
        self.screen.blit(
            self.font_title.render("Wilds Chart", True, settings.COLOR_TEXT),
            (panel.x + 28, panel.y + 10),
        )
        self.screen.blit(
            self.font_small.render(
                f"Fog lifts as you explore. [{map_key}] to close. You: gold dot. Pins: discovered places.",
                True,
                settings.COLOR_TEXT_DIM,
            ),
            (panel.x + 220, panel.y + 22),
        )

        lx = panel.right - legend_w - 16
        ly = panel.y + 52
        pygame.draw.rect(self.screen, (22, 28, 40), pygame.Rect(lx, ly, legend_w - 8, map_pixel_h), border_radius=8)
        pygame.draw.rect(self.screen, (55, 72, 100), pygame.Rect(lx, ly, legend_w - 8, map_pixel_h), 1, border_radius=8)
        self.screen.blit(self.font_ui.render("Discovered places", True, settings.COLOR_ACCENT), (lx + 12, ly + 10))
        legend_y = ly + 44
        discovered_list = [p for p in WORLD_POIS if str(p["id"]) in self.discovered_pois]
        discovered_list.sort(key=lambda p: (str(p.get("kind", "")), str(p["name"])))
        row_h = 22
        max_rows = min(len(discovered_list), (map_pixel_h - 52) // row_h)
        for i, poi in enumerate(discovered_list[:max_rows]):
            kind = str(poi.get("kind", "wild"))
            col = POI_KIND_COLORS.get(kind, (180, 180, 180))
            cy = legend_y + i * row_h
            pygame.draw.polygon(
                self.screen,
                col,
                [(lx + 18, cy - 4), (lx + 26, cy), (lx + 18, cy + 4), (lx + 10, cy)],
            )
            name = str(poi["name"])
            if len(name) > 26:
                name = name[:24] + "…"
            self.screen.blit(self.font_small.render(name, True, settings.COLOR_TEXT), (lx + 34, cy - 8))
        if len(discovered_list) > max_rows:
            self.screen.blit(
                self.font_small.render(f"+ {len(discovered_list) - max_rows} more…", True, settings.COLOR_TEXT_DIM),
                (lx + 12, legend_y + max_rows * row_h + 4),
            )

        kinds_used = sorted({str(p.get("kind", "")) for p in discovered_list})
        ly2 = ly + map_pixel_h - 36
        self.screen.blit(self.font_small.render("Key:", True, settings.COLOR_TEXT_DIM), (lx + 12, ly2))
        cx = lx + 52
        for k in kinds_used[:5]:
            if cx > lx + legend_w - 40:
                break
            c = POI_KIND_COLORS.get(k, (150, 150, 150))
            pygame.draw.circle(self.screen, c, (cx, ly2 + 6), 5)
            cx += 18

    def draw_dialogue(self) -> None:
        if not self.dialogue_npc:
            return
        panel = pygame.Rect(90, 510, 1100, 180)
        pygame.draw.rect(self.screen, (14, 20, 30), panel, border_radius=10)
        pygame.draw.rect(self.screen, (65, 90, 126), panel, 2, border_radius=10)
        self.screen.blit(self.font_ui.render(self.dialogue_npc.name, True, settings.COLOR_ACCENT), (120, 535))
        text = self.dialogue_npc.dialogue[self.dialogue_index]
        self.screen.blit(self.font_ui.render(text, True, settings.COLOR_TEXT), (120, 572))
        self.screen.blit(self.font_small.render("Enter to continue", True, settings.COLOR_TEXT_DIM), (120, 622))

    def draw_shop(self) -> None:
        if not self.shop_id:
            return
        panel = pygame.Rect(240, 120, 800, 500)
        pygame.draw.rect(self.screen, (20, 28, 40), panel, border_radius=10)
        pygame.draw.rect(self.screen, (65, 90, 126), panel, 2, border_radius=10)
        self.screen.blit(self.font_title.render(SHOPS[self.shop_id]["name"], True, settings.COLOR_TEXT), (300, 150))
        items = list(SHOPS[self.shop_id]["items"].items())
        for i, (item_id, price) in enumerate(items):
            c = settings.COLOR_ACCENT if i == self.shop_index else settings.COLOR_TEXT
            self.screen.blit(self.font_ui.render(f"{'> ' if i==self.shop_index else '  '}{ITEM_DEFS[item_id].name} - {price}c", True, c), (300, 220 + i * 42))
        self.screen.blit(self.font_small.render("Enter buy | Esc leave", True, settings.COLOR_TEXT_DIM), (300, 570))

    def draw_settings(self) -> None:
        self.screen.fill((16, 24, 34))
        self.screen.blit(self.font_title.render("Controls / Rebinding", True, settings.COLOR_TEXT), (420, 60))
        for i, action in enumerate(self.settings_actions):
            c = settings.COLOR_ACCENT if i == self.settings_index else settings.COLOR_TEXT
            self.screen.blit(self.font_ui.render(f"{'> ' if i==self.settings_index else '  '}{action}: {self.keybinds[action]}", True, c), (300, 130 + i * 38))
        hint = f"Rebinding: {self.rebinding} (press key)" if self.rebinding else "Enter to rebind, Esc to menu"
        self.screen.blit(self.font_small.render(hint, True, settings.COLOR_TEXT_DIM), (300, 620))

    def draw_game_over(self) -> None:
        ov = pygame.Surface(settings.WINDOW_SIZE, pygame.SRCALPHA)
        ov.fill((0, 0, 0, 170))
        self.screen.blit(ov, (0, 0))
        self.screen.blit(self.font_big.render("GAME OVER", True, settings.COLOR_WARNING), (410, 250))
        self.screen.blit(self.font_ui.render("Press Enter to return to menu", True, settings.COLOR_TEXT), (440, 350))

    def bar(self, x: int, y: int, w: int, ratio: float, color: tuple[int, int, int], label: str) -> None:
        pygame.draw.rect(self.screen, (30, 36, 50), pygame.Rect(x, y, w, 18), border_radius=5)
        pygame.draw.rect(self.screen, color, pygame.Rect(x, y, int(w * max(0, min(1, ratio))), 18), border_radius=5)
        self.screen.blit(self.font_small.render(label, True, (245, 245, 245)), (x + w + 8, y + 1))

    def set_popup(self, txt: str) -> None:
        self.popup = txt
        self.popup_timer = 2.2

    def new_game(self) -> None:
        self.player = Player(22 * 32, 18 * 32)
        self.inventory = Inventory({"apple": 3, "berry": 2, "minor_potion": 1})
        self.quest_log = QuestLog(active=["welcome_to_eldervale", "forager_path", "orchard_harvest"], completed=[])
        self.enemies = []
        self.money = 30
        self.time_of_day = 8.0
        self.weather = "clear"
        self.day_count = 1
        self.map_reveal = [[0 for _ in range(self.world.w)] for _ in range(self.world.h)]
        # Village POIs known from the start (no popups); the rest unlock by exploration.
        self.discovered_pois = {
            "eldervale",
            "gate_east",
            "gate_south",
            "npc_rowan",
            "shop_orra",
            "shop_lyra",
            "herbalist_mira",
            "farmer_tobin",
        }
        self.boss_spawned = False
        self.boss_defeated = False
        self.world._spawn_points()

    def load_game(self, initial: bool = False) -> None:
        data = SaveSystem.load()
        if not data:
            if initial:
                self.new_game()
            return
        self.player.load_dict(data.get("player", {}))
        self.inventory = Inventory(data.get("inventory", {}))
        q = data.get("quests", {})
        self.quest_log = QuestLog(active=[], completed=q.get("completed", []))
        for qid, prog in q.get("active", {}).items():
            self.quest_log.ensure(qid)
            self.quest_log.active[qid] = int(prog)
        self.money = int(data.get("money", 30))
        self.keybinds.update(data.get("keybinds", {}))
        meta = data.get("meta", {})
        self.time_of_day = float(meta.get("day_time", 8.0))
        self.weather = meta.get("weather", "clear")
        self.day_count = int(meta.get("day", 1))
        self.map_reveal = data.get("map_reveal", self.map_reveal)
        self.discovered_pois = set(data.get("discovered_pois", []))
        self.boss_defeated = bool(data.get("boss_defeated", False))
        self.boss_spawned = bool(data.get("boss_spawned", False))
        for ws, s in zip(self.world.weapon_spawns, data.get("weapon_spawns", [])):
            ws["taken"] = bool(s.get("taken", False))
        for g, s in zip(self.world.gatherables, data.get("gatherables", [])):
            g["respawn"] = float(s.get("respawn", 0))

    def manual_save(self) -> None:
        data = {
            "player": self.player.to_dict(),
            "inventory": self.inventory.to_dict(),
            "money": self.money,
            "quests": self.quest_log.to_dict(),
            "keybinds": self.keybinds,
            "meta": {"day_time": self.time_of_day, "weather": self.weather, "day": self.day_count, "playtime": self.runtime_seconds},
            "map_reveal": self.map_reveal,
            "discovered_pois": sorted(self.discovered_pois),
            "boss_spawned": self.boss_spawned,
            "boss_defeated": self.boss_defeated,
            "weapon_spawns": [{"taken": w["taken"]} for w in self.world.weapon_spawns],
            "gatherables": [{"respawn": g["respawn"]} for g in self.world.gatherables],
        }
        SaveSystem.save(data)

    def is_action_key(self, key: int, action: str) -> bool:
        return key == self.key_to_pg(self.keybinds[action])

    def key_to_pg(self, name: str) -> int | None:
        table = {
            "w": pygame.K_w, "a": pygame.K_a, "s": pygame.K_s, "d": pygame.K_d, "e": pygame.K_e,
            "f": pygame.K_f, "j": pygame.K_j, "m": pygame.K_m, "tab": pygame.K_TAB, "space": pygame.K_SPACE,
            "escape": pygame.K_ESCAPE, "lshift": pygame.K_LSHIFT, "up": pygame.K_UP, "down": pygame.K_DOWN,
            "left": pygame.K_LEFT, "right": pygame.K_RIGHT, "return": pygame.K_RETURN,
        }
        return table.get(name)
