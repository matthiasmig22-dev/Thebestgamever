from __future__ import annotations

import math
import pygame
from asset_helpers import draw_player_sprite


class Player:
    def __init__(self, x: float, y: float) -> None:
        self.x = x
        self.y = y
        self.w = 26
        self.h = 26
        self.speed = 150.0
        self.sprint_mult = 1.65
        self.roll_speed = 360.0
        self.roll_timer = 0.0
        self.roll_cooldown = 0.0
        self.face = pygame.Vector2(1, 0)

        self.max_health = 100.0
        self.health = 100.0
        self.max_stamina = 100.0
        self.stamina = 100.0

        self.attack_cooldown = 0.0
        self.attack_timer = 0.0
        self.hit_flash = 0.0
        self.iframes = 0.0
        self.hit_enemy_ids: set[int] = set()

    @property
    def rect(self) -> pygame.Rect:
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)

    def to_dict(self) -> dict:
        return {
            "x": round(self.x, 2),
            "y": round(self.y, 2),
            "health": round(self.health, 2),
            "stamina": round(self.stamina, 2),
        }

    def load_dict(self, data: dict) -> None:
        self.x = data.get("x", self.x)
        self.y = data.get("y", self.y)
        self.health = float(data.get("health", self.health))
        self.stamina = float(data.get("stamina", self.stamina))

    def update_needs(self, dt: float) -> None:
        # Passive regeneration with no hunger mechanic.
        self.health = min(self.max_health, self.health + 0.8 * dt)

        if self.roll_timer <= 0:
            self.stamina = min(self.max_stamina, self.stamina + 16.0 * dt)

        self.attack_cooldown = max(0.0, self.attack_cooldown - dt)
        self.attack_timer = max(0.0, self.attack_timer - dt)
        self.roll_timer = max(0.0, self.roll_timer - dt)
        self.roll_cooldown = max(0.0, self.roll_cooldown - dt)
        self.iframes = max(0.0, self.iframes - dt)
        self.hit_flash = max(0.0, self.hit_flash - dt)

    def movement_vector(self, key_state: dict[str, bool]) -> pygame.Vector2:
        x = (1 if key_state.get("move_right") else 0) - (1 if key_state.get("move_left") else 0)
        y = (1 if key_state.get("move_down") else 0) - (1 if key_state.get("move_up") else 0)
        vec = pygame.Vector2(x, y)
        if vec.length_squared() > 0:
            vec = vec.normalize()
            self.face = vec
        return vec

    def move_with_collision(self, move: pygame.Vector2, dt: float, world_collides) -> None:
        if move.length_squared() <= 0:
            return
        nx = self.x + move.x * dt
        ny = self.y + move.y * dt
        test_x = pygame.Rect(int(nx), int(self.y), self.w, self.h)
        if not world_collides(test_x):
            self.x = nx
        test_y = pygame.Rect(int(self.x), int(ny), self.w, self.h)
        if not world_collides(test_y):
            self.y = ny

    def get_speed(self, sprinting: bool) -> float:
        if self.roll_timer > 0:
            return self.roll_speed
        if sprinting and self.stamina > 0:
            return self.speed * self.sprint_mult
        return self.speed

    def spend_stamina_for_sprint(self, sprinting: bool, dt: float) -> None:
        if sprinting and self.stamina > 0:
            self.stamina = max(0.0, self.stamina - 24.0 * dt)

    def try_roll(self) -> bool:
        if self.roll_cooldown > 0 or self.stamina < 25:
            return False
        self.roll_timer = 0.22
        self.roll_cooldown = 0.55
        self.stamina -= 25
        self.iframes = 0.18
        return True

    def try_attack(self) -> bool:
        if self.attack_cooldown > 0:
            return False
        self.attack_timer = 0.18
        self.attack_cooldown = 0.32
        self.hit_enemy_ids.clear()
        return True

    def attack_rect(self) -> pygame.Rect:
        r = self.rect
        dist = 20
        size = 34
        dx = int(round(self.face.x))
        dy = int(round(self.face.y))
        if abs(self.face.x) > abs(self.face.y):
            return pygame.Rect(r.centerx + dx * dist - size // 2, r.centery - size // 2, size, size)
        return pygame.Rect(r.centerx - size // 2, r.centery + dy * dist - size // 2, size, size)

    def take_damage(self, amount: float) -> bool:
        if self.iframes > 0:
            return False
        self.health = max(0.0, self.health - amount)
        self.hit_flash = 0.2
        self.iframes = 0.35
        return True

    def draw(self, surf: pygame.Surface, cam_x: float, cam_y: float) -> None:
        r = self.rect.move(-int(cam_x), -int(cam_y))
        anim_phase = abs(math.sin((self.x + self.y) * 0.01))
        draw_player_sprite(surf, r, self.face, anim_phase, self.hit_flash > 0)
        if self.attack_timer > 0:
            ar = self.attack_rect().move(-int(cam_x), -int(cam_y))
            slash = pygame.Surface((ar.w, ar.h), pygame.SRCALPHA)
            pygame.draw.ellipse(slash, (255, 240, 180, 120), slash.get_rect(), 2)
            surf.blit(slash, ar.topleft)
